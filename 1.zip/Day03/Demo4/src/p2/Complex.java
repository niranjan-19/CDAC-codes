package p2;

public class Complex {

	int num1 = 45;
	private int num2 = 10;
	protected int num4 = 52;
	public int num3 = 21;

	void display() {
		System.out.println(num1);
		System.out.println(num2);
		System.out.println(num3);
		System.out.println(num4);

	}

}
