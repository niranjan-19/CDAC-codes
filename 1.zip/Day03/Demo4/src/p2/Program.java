package p2;

public class Program {
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Complex c = new Complex();

		System.out.println("num1:" + c.num1);
		System.out.println("num2:" + c.num2);// Private member is not accessible
		System.out.println("num3:" + c.num3);
		System.out.println("num4:" + c.num4);

	}

}
