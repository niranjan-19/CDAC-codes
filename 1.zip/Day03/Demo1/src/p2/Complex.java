package p2;

import java.util.Scanner;

public class Complex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Complex1 c1 = new Complex1();
		
		c1.acceptnumber();
       		c1.displaynumber();
       		
       		
       		Complex1 c2 =new Complex1();
       		c2.acceptnumber();
       		c2.displaynumber();
	}

}



class Complex1{
	int real ;
    int imag;

    void acceptnumber()
    {
    	System.out.println("Enter real :");
    	
    	Scanner sc = new Scanner (System.in);
        this.real = sc.nextInt();    	
    
         System.out.println("Enter imag :");
    	   this.imag = sc.nextInt(); 
    }
	
    void displaynumber() {
    	
    	System.out.println("Real is "+this.real);
    	System.out.println("Imaginary is "+this.imag);
    	
    }
}