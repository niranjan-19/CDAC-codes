class Complex {

	int real;
	int imag;

	Complex() {

		System.out.println("Inside Parameterless Constructor");

		this.real = 10;
		this.imag = 20;

	}

	Complex(int real, int imag) {

		System.out.println("Inside Paramertised Constructor");

		this.real = real;
		this.imag = imag;

	}

	void acceptnumber() {
		System.out.println("Enter real :");

		// Scanner sc = new Scanner (System.in);
		// this.real = sc.nextInt();

		// System.out.println("Enter imag :");
		// this.imag = sc.nextInt();
	}

	void displaynumber() {

		System.out.println("Real is " + this.real);
		System.out.println("Imaginary is " + this.imag);

	}

}

public class Program {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Complex c1 = new Complex();

		c1.acceptnumber();
		c1.displaynumber();

		Complex c2 = new Complex(45, 78); // Adding parameters at the time of creating objects

		c2.acceptnumber();
		c2.displaynumber();

	}

}
