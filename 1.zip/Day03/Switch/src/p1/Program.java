package p1;

import java.util.Scanner;

public class Program {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int choice ;
do {
System.out.println("0.EXIT");
System.out.println("1.Idli");
System.out.println("2.Wada");
System.out.println("3.Poha");
System.out.println("4.Dosa");



System.out.print("Enter your choice :");

Scanner sc = new Scanner(System.in);
choice = sc.nextInt();


switch (choice) {
case 0:
	System.out.println("Thank you");
	break;
case 1:
	
	System.out.println("You have selected Idli");
	break;
	
case 2:

	System.out.println("You have selected Wada");
	break;
case 3:
	System.out.println("You have selected Poha");
	break;
	
case 4:
	System.out.println("You have selected Dosa");
	break;
	
default:
	System.out.println("Invalid Choice ");

}

} while (choice!=0);	
		
		
		
	}

}
