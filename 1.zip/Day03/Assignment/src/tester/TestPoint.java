package tester;

public class TestPoint {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
