package com.app.geometry;

public class Point2D {

	int x;
	int y;

	public Point2D() {

	}

	public Point2D(int x, int y) {
		this.x = x;
		this.y = y;
	}

	public String getDetails() {
		return null;

	}

	public boolean isEqual(Point2D other) {
		return this.x == other.x && this.y == other.y;

	}

	public double calculateDistance(Point2D other) {
		return x;

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Point2D p1 = new Point2D(15, 14);
		Point2D p2 = new Point2D(20, 10);
		System.out.println(p1.isEqual(p2));

		// if (p1.isEqual(p2))
//
//		{
//			System.out.println("True");
//		} else
//			System.out.println("False");

		p1.calculateDistance(p2);

	}

}
