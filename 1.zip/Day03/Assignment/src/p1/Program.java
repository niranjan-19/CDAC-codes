
//Assignment 02 ==>Menu driven ==>submenus

package p1;

import java.util.Scanner;

public class Program {
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int choice;
		int choice1;
		int quantity;
		int b1 = 0;
		int b2 = 0;
		int b3 = 0;
		int b4 = 0;
		int bill;

		do {
			System.out.print("Enter your Main choice :");

			@SuppressWarnings("resource")
			Scanner sc = new Scanner(System.in);
			choice = sc.nextInt();

			switch (choice) {
			case 0:
				System.out.println("Visit Again Thank you");
				break;
			case 1:

				System.out.println("0.EXIT");
				System.out.println("1.Idli RS.20");
				System.out.println("2.Wada RS.20");
				System.out.println("3.Poha RS.15");
				System.out.println("4.Dosa RS.40");
				do {
					System.out.print("Enter your choice :");

					@SuppressWarnings("resource")
					Scanner sc1 = new Scanner(System.in);
					choice1 = sc1.nextInt();

					switch (choice1) {

					case 1:
						System.out.println("You have selected Idli ");

						System.out.print("Enter quantity:");
						Scanner sc2 = new Scanner(System.in);
						quantity = sc2.nextInt();
						b1 = quantity * 20;
						System.out.println("Your Bill is " + b1);

						break;

					case 2:
						System.out.println("You have selected Wada ");

						System.out.print("Enter quantity:");
						Scanner sc3 = new Scanner(System.in);
						quantity = sc3.nextInt();
						b2 = quantity * 20;

						System.out.println("Your Bill is " + b2);
						break;
					case 3:
						System.out.println("You have selected Poha");
						System.out.print("Enter quantity:");
						Scanner sc4 = new Scanner(System.in);
						quantity = sc4.nextInt();
						b3 = quantity * 15;

						System.out.println("Your Bill is " + b3);

						break;
					case 4:
						System.out.println("You have selected Dosa ");
						System.out.print("Enter quantity:");
						Scanner sc5 = new Scanner(System.in);
						quantity = sc5.nextInt();
						b4 = quantity * 40;

						System.out.println("Your Bill is " + b4);

						break;

					default:
						System.out.println("Invalid Choice ");
					}
				} while (choice1 != 0);
				break;

			case 2:

				bill = b1 + b2 + b3 + b4;

				System.out.println("Your Total  Bill is :" + bill);

				break;

			default:
				System.out.println("Invalid choice");

			}

		} while (choice != 0);

	}

}
