class Employees {

	int empid;
	double salary;
	String name;

	static int generate_empid;

	static {

		generate_empid = 1000;
	}

	Employees() {

		this(5000, "");

	}

	Employees(double salary, String name) {

		this.empid = ++generate_empid;
		this.salary = salary;
		this.name = name;

	}

	void displayinfo() {
		System.out.println("Empid  :" + this.empid);
		System.out.println("Salary : " + this.salary);
		System.out.println("Name :" + this.name);

	}

}

public class Program {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Employees e1 = new Employees();
		Employees e2 = new Employees();
		Employees e3 = new Employees(7000, "Rohan");

		e1.displayinfo();
		e2.displayinfo();
		e3.displayinfo();

	}

}
