package demo01;

public class demo02 {

	public static void main(String[] args) {
		
		
		// TODO Auto-generated method stub

//while loop 

		int arr[] = { 11,22,33,44,55,66,77};

int i=0 ;
while(i<7)

{
	System.out.println(arr[i]);
	
	i++;

	
}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
