package demo01;

public class demo05 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//key found
		
		int key=44;
		
int arr[] = {11,22,33,44,55,66,77};
		
		int i=0;
		
		for (i=0;i<7;i++)
		{
			
			if (arr[i]==key)
				
			{
				System.out.println("Key is Found");
			}
			
			else
				System.out.println("Key is not found");
		}
			
		
	}

}
