package demo01;

public class demo04 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
//for loop
		
		int arr[] = {11,22,33,44,55,66,77};
		
		int i=0;
		
		for (i=0;i<7;i++)
		{
			if (arr[i]%2==0)
			{
				System.out.println(arr[i]+"is even");
			
			}
			else
			{
				System.out.println(arr[i] + "is odd");
			}
				
				
		
			//System.out.println(arr[i]);
		}
	
	
	}

}