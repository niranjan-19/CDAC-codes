
public class Program {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
double num2=10.5 ;

int num1= (int)num2 ;

System.out.println(num1);

	}

}
