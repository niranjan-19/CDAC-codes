package com.sunbeaminfo;

import java.util.Scanner;

public class Employees {

	int empid;
	double sal;
	String name;

	// Parameterless Constructor
	public Employees() {

		this(0, 0, "");

	}

	// Parameterized Constructor
	public Employees(int empid, double sal, String name) {
		this.empid = empid;
		this.sal = sal;
		this.name = name;
	}

	public void acceptEmp() {

		Scanner sc = new Scanner(System.in);

		System.out.println("Enter Employee ID");
		empid = sc.nextInt();
		System.out.println("Enter Employee Salray");
		sal = sc.nextDouble();

		System.out.println("Enter Employee Name");
		name = sc.next();

	}
	public void displayEmp() {

		System.out.println("Empid:   " + empid);
		System.out.println("Salary:  " + sal);
		System.out.println("Name:    " + name);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Employees[][] empArr = new Employees[3][2];

		// empArr[0][0]= new Employees();
		// empArr[0][0].acceptEmp();
		// empArr[0][0].displayEmp();
		//
		// for Accepting employees details
		for (int row = 0; row < empArr.length; row++) {
			for (int col = 0; col < empArr[row].length; col++) {

				empArr[row][col] = new Employees(); // create instance for
													// reference
				empArr[row][col].acceptEmp();
			}

		}

		// for displaying employees details
		for (int row = 0; row < empArr.length; row++) {
			for (int col = 0; col < empArr[row].length; col++) {
				empArr[row][col].displayEmp();
			}

		}

	}

}
