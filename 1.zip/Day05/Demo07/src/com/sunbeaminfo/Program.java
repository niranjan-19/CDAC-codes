package com.sunbeaminfo;

import java.util.StringTokenizer;

public class Program {

	public static void main(String[] args) {
		String str = "Hello .World!.This.is.a.StringTokenizer.example."; 
		StringTokenizer tokenizer = new StringTokenizer(str, ".");  // can specify the delimiter here "" space is delimiter
		
		 //StringTokenizer tokenizer = new StringTokenizer(str, ".",true); // if need to print delimiter too 
		
		System.out.println(tokenizer.countTokens());   // TO count the number of tokens in String
		
		while (tokenizer.hasMoreTokens()) {             // 	hasMoreTokens() Tests if there are more tokens available from this tokenizer's string.
			System.out.println(tokenizer.nextToken());   //  nextToken () Returns the next token from this string tokenizer.
			
		}
	}

}
