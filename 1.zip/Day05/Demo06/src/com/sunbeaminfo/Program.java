package com.sunbeaminfo;

public class Program {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		StringBuffer sb = new StringBuffer("Hello");
		
		sb.append("World");   // append() method to append mutable string 		
		
		String sf = sb.toString();
		
		System.out.println(sf);
		
		
		
	}

}


// StringBuilder 

/*

StringBuilder sb = new StringBuilder("Hello");

// Appending a string
sb.append(" World");

// Inserting a string at a particular position
sb.insert(5, " Java");

// Replacing a substring with another string
sb.replace(0, 5, "Hi");

// Deleting a substring
sb.delete(2, 4);

// Converting the contents of the StringBuilder to a string
String str = sb.toString();

*/