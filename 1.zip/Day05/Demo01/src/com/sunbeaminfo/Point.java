package com.sunbeaminfo;

import java.util.Scanner;

public class Point {

	private int x;
	private int y;
	
	public Point() {
	 this(0,0);	
		
	}
	
	public Point(int x, int y) {
	
		this.x=x;
		this.y=y;
	}

	public void acceptNumber()
	{
		Scanner sc = new  Scanner(System.in);
		System.out.println("Enter value of X");
		this.x=sc.nextInt();
		System.out.println("Enter Value of Y");
		this.y=sc.nextInt();
		
	}

	public void displayNumber() {
		
		System.out.println("Point is ("+ this.x+ "," +this.y +")" );
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Point[] pointArr = new Point[5]; // creating array of references 
		
//		pointArr[0]=new Point();  		// create object of each reference so that Null pointer exception does not occur 
//		
//		pointArr[0].acceptNumber();
//		pointArr[0].displayNumber();
		
		pointArr[1]= new Point(20,50);  		// create object of each reference so that Null pointer exception does not occur
		
		//pointArr[1].acceptNumber(); //NOT needed as you are passing parameters
		pointArr[1].displayNumber();
		
		
	}

}
