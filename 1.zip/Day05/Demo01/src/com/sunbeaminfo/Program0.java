package com.sunbeaminfo;

public class Program0 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Point [] pointArr = new Point[5];
		
		for (int i=0;i<pointArr.length ;i++)   //a
		{
			pointArr[i]= new Point();
			
			pointArr[i].acceptNumber();
			pointArr[i].displayNumber();
			
		}
		
	}

}
