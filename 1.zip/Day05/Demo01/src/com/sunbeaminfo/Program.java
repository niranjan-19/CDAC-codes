package com.sunbeaminfo;

import java.util.Arrays;

public class Program {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr=new int[5];

arr[0]=10;
arr[1]=90;
arr[2]=30;
arr[3]=70;
arr[4]=50;

Arrays.sort(arr); //method of Arrays class 


for (int i=0;i<5;i++) {
	
	//System.out.println(Arrays.toString(arr)); // converts o/p to string format 
	
	System.out.println(arr[i]);
	

	
	
}
	}

}
