package com.sunbeaminfo;

public class Program {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int count=0;

int arr[][]= new int[5][3];
		
for (int r=0;r<arr.length;r++)   // for rows
{
	
	for (int c=0;c<arr[r].length;c++) // for columns 
	{
		arr[r][c]=(++count*10);
				
	}
}

for(int r = 0; r<arr.length;r++) {
	
	for(int c= 0; c<arr[r].length;c++) {
		System.out.println("arr["+r+"]["+c+"]="+arr[r][c]);
	}
}
		
		
	}

}
