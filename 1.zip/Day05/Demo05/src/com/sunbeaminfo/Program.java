package com.sunbeaminfo;

public class Program {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s1 ="Sunbeam";                     // Literal Pool/Constant Pool 
		String s2 = new String("Sunbeam ");       //creates new Object 
		String s3 = "Sunbeam";
		String s4 = new String("Sunbeam");        // s2 and s4 ==> Points to different objects 
		
		
		
		if (s2==s4)
			System.out.println("Equal");
		else 
			System.out.println("Not Equal");
		
	}

}
