package com.sunbeaminfo;


//equals method in String 
public class Program0 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s1 = "Sun";
		String s2 ="beam";
		String s3 ="Sunbeam";
		String s4 = "Sunbeam";
		String s12 = new String ("Sunbeam");
		
	String s5 = new String ("Infotech");
	String s6 = new String ("Infotech");
	
	String s7 = s1 + s2 ;                  //Concat two strings ==> creates object s7
	                                     
	String s8 = "Sun"	+ "beam";          //Concat two strings 

	String s9 = "Sun".concat("beam");      // concat method 
	
	String s10 = "Sun".concat(s2);
	
	String s11 = ((s1).concat(s2)).intern(); // intern method converts objects into literals 	
	
	String s13 = (s12.intern());
	//System.out.println(s10);
	
	
		if(s13.equals(s4))
			System.out.println("Equal");
		else
			System.out.println("Not Equal");
	}

}
