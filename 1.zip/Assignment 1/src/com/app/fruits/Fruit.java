package com.app.fruits;
import java.util.Scanner;

public  class Fruit {
	protected String color;
	protected double weight;
	 protected String name;
	protected boolean isFresh;
	
	public Fruit(String color, double weight, String name, boolean isFresh) {
		super();
		this.color = color;
		this.weight = weight;
		this.name = name;
		this.isFresh = isFresh;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public double getWeight() {
		return weight;
	}
	public void setWeight(double weight) {
		this.weight = weight;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public boolean getisFresh() {
		return isFresh;
	}
	public void setFresh(boolean isFresh) {
		this.isFresh = isFresh;
	}
	
	public String toString() {
		return "color="+this.color+"weight="+this.weight+"name="+this.name+"Is it Fresh"+this.isFresh;
	}
	public String taste() {
		return "no specific taste";
	}
	public void acceptData() {
		Scanner sc=new Scanner(System.in);
				System.out.println("which color");
				this.color=sc.nextLine();
				System.out.println("what is weight..?");
				this.weight=sc.nextInt();
				System.out.println("name of the fruit");
				this.name=sc.nextLine();
				System.out.println("is it fresh");
				this.isFresh=sc.nextBoolean();
		}
	public void displayData() {
		System.out.println("color="+this.color+"  weight="+this.weight+"  name="+this.name+"  Is it Fresh"+this.isFresh);
	}

}
