package com.app.fruits;

public  class Apple extends Fruit {
	public Apple(String color, double weight, String name, boolean isFresh) {
		super(color, weight, name, isFresh);
		// TODO Auto-generated constructor stub
	}
	
@Override
	public void acceptData() {
		// TODO Auto-generated method stub
		super.acceptData();
	}
	public String toString() {
		return "color="+super.color+"weight="+super.weight+"name="+super.name+"Is it Fresh"+super.isFresh;
	}
	public String taste() {
		return "sweet n sour";
	}
	
}