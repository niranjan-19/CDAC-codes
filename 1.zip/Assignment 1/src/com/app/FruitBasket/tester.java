package com.app.FruitBasket;
import java.util.Scanner;

import com.app.*;
import com.app.fruits.Apple;
import com.app.fruits.Fruit;
import com.app.fruits.Mango;
import com.app.fruits.Orange;
public class tester {
	static int menu() {
		
		System.out.println("1.Add Mango");
		System.out.println("2.Add orange");
		System.out.println("3.Add Apple");
		System.out.println("4.Display all the fruits in the basket");
		System.out.println("5.Display name, color,weight,taste of all fresh fruits");
		System.out.println("6. Display tastes of all stale(not fresh) fruits in the basket.");
		System.out.println("7.Mark a fruit as a stale");
		System.out.println("10.Exit");
		return new Scanner(System.in).nextInt();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("enter no of fruits you want to store");
		int num=new Scanner(System.in).nextInt();
		Fruit fruit[]=new Fruit[num];
		
		int counter=0;
		int choice;
		while((choice=tester.menu()) != 10)
		{switch(choice) {
		case 1: 
			if (counter<num) {
			fruit[counter++]=new Mango("yellow",50,"m1",true);
			}
			else 
				System.out.println("Basket is Full");
			break;
		case 2: 
			if (counter<num)
			fruit[counter++]=new Orange("orange",40,"O1",true);
			else
			System.out.println("Basket is Full");
			break;
		case 3: 
			if (counter<num)
			fruit[counter++]=new Apple("red",60,"A1",true);
			else
			System.out.println("Basket is Full");
			break;
		case 4:
			System.out.println("following is the list of all the fruits in the basket");
			for(Fruit fru:fruit)
				if (fru!=null)
				{//fru.displayData();
				System.out.println("color="+fru.getColor()+"  weight="+fru.getWeight()+"  name="+fru.getName()+"  Is it Fresh  "+fru.getisFresh());
			System.out.println(".......................................");
				}break;
		case 5:
			System.out.println("following are the fresh fruits");
			for(Fruit fru:fruit)
				if (fru!=null) {
			if (fru.getisFresh()== true) {
				if(fru instanceof Apple)
				{ Apple a1=(Apple)fru;
				System.out.println("color="+fru.getColor()+"  weight="+fru.getWeight()+"  name="+fru.getName()+"  taste="+a1.taste());
	    		}
				if(fru instanceof Orange)
				{ Orange o1=(Orange)fru;
				System.out.println("color="+fru.getColor()+"  weight="+fru.getWeight()+"  name="+fru.getName()+"  taste="+o1.taste());
	    		}
				if(fru instanceof Mango)
				{ Mango m1=(Mango)fru;
				System.out.println("color="+fru.getColor()+"  weight="+fru.getWeight()+"  name="+fru.getName()+"  taste="+m1.taste());
	    		}
				}
				}
				break;
		case 6:
	    for(Fruit fru:fruit)
	    	if (fru!=null) {
		if (fru.getisFresh()!= true) {
			System.out.println("tastes of all stale(not fresh) fruits in the basket");
			if (fru instanceof Apple) {
				Apple a1=(Apple)fru;
			System.out.println(a1.taste());}
			else if(fru instanceof Orange) {
				Orange o1=(Orange)fru;
			System.out.println(o1.taste());
			}else {
				
				Mango m1=(Mango)fru;
				System.out.println(m1.taste());
			}			}
		else 
			System.out.println("No stale fruits in the Basket");}
	    	break;
	    
		case 7:
		System.out.println("which fruit has become stale");	
		int stale=new Scanner(System.in).nextInt();
		fruit[stale].setFresh(false);
			break;
		}
			
		}
		//System.out.println("Thank You visit again....!!!!");
			
		}
			
		

	}


