import java.util.Scanner;

public class Program {

	public static void main(String[] args) {
		
		
        Scanner scan = new Scanner(System.in);
        
        String str = scan.nextLine();
        
        System.out.println("String:"+str);
       
       double d= scan.nextDouble();
       
       
     System.out.println("Double:" +d);
       
        int i = scan.nextInt();

        System.out.println("Integer:" +i);
	//Scanner(close);
}
}
