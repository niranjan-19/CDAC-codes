package com.sundeamtest;

import java.util.Scanner;
import com.sundeam.*;



public  class Tester {
	
	public static int menu() {
		System.out.println("0.Exit");
		System.out.println("1.Salaried Employee");
		System.out.println("2.Hourly Employee");
		System.out.println("3.Commission Employee");
		System.out.println("4.Base salary and commission");
		
		
		
		return new Scanner(System.in).nextInt();	
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println("welcome which type of employee are you");
Employee e1;
int choice;
while((choice=Tester.menu())!=0) {
	switch (choice)
	{
	case 1: e1=new Sal_emp();
	e1.acceptData();
	e1.calSal();
	System.out.println(e1);
	break;
	case 2: e1= new Hr_emp();
		e1.acceptData();
		e1.calSal();
		System.out.println(e1);
		break;
	case 3: e1=new Comm_emp();
	      e1.acceptData();
	      e1.calSal();
	      System.out.println(e1);
         break;
	case 4: e1=new Base_comm();
	e1.acceptData();
	e1.calSal();
	System.out.println(e1);
	break;
	default: System.out.println("Enter valid details");
	}
	
	
	
}


	}

}
