package com.sundeam;

public abstract class Employee {
	private String firstname;
	 private String lastname;
	private int SSN;
	 
	public Employee() {
		
	}
	@Override
	public String toString() {
		return "Employee [firstname=" + firstname + ", lastname=" + lastname + ", SSN=" + SSN + "]";
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public int getSSN() {
		return SSN;
	}
	public void setSSN(int sSN) {
		SSN = sSN;
	}
	
	public abstract void acceptData();
	public abstract void calSal();
	
}
	 


