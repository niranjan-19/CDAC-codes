package com.sundeam;
import java.util.Scanner;
public class Hr_emp extends Employee{
	private int hr_wage=200 ;
	private double salary;
	Scanner sc=new Scanner(System.in);
	
	
	@Override
	public String toString() {
		return "Hr_emp [hr_wage=" + hr_wage + ", salary=" + salary + ", First name=" + getFirstname()
				+ ", Lastname=" + getLastname() + ", SSN=" + getSSN() + "]";
	}

	@Override
	public void acceptData() {
		// TODO Auto-generated method stub
		System.out.println("enter the firstname");
		setFirstname(sc.next());
		System.out.println("enter the lastname");
		setLastname(sc.next());
		System.out.println("enter the SSN");
		setSSN(sc.nextInt());
	}

	@Override
	public void calSal() {
		System.out.println("how many hours have you workes...??");
		int hr=sc.nextInt();
		if (hr<=40) {
			System.out.println("your salary is "+hr_wage*hr);
			salary=hr_wage*hr;
		}else
		{
			salary=hr_wage*40+(1.5*hr_wage*(hr-40));
			System.out.println("your salary is "+salary);
		}
		
		
	}
	
	

}
