package com.sundeam;
import java.util.Scanner;
public class Base_comm extends Comm_emp{
		
		double base=5000;
	
	Scanner sc=new Scanner(System.in);
	@Override
	public void acceptData() {
		// TODO Auto-generated method stub
		System.out.println("enter the firstname");
		setFirstname(sc.next());
		System.out.println("enter the lastname");
		setLastname(sc.next());
		System.out.println("enter the SSN");
		setSSN(sc.nextInt());
		System.out.println("enter the Sales");
		super.setSales(sc.nextInt());
	}

	@Override
	public void calSal() {
		// TODO Auto-generated method stub
		super.setSalary(base+(super.getComm_rate()*super.getSales()));
		
		System.out.println("your salary is "+super.getSalary());
	}

	
	
}
