package com.sundeam;
import java.util.Scanner;
public class Comm_emp extends Employee {
	private double salary;
	private double Comm_rate =0.20;
	private int sales;
	Scanner sc=new Scanner(System.in);
	
	
	public double getSalary() {
		return salary;
	}


	public void setSalary(double salary) {
		this.salary = salary;
	}


	public double getComm_rate() {
		return Comm_rate;
	}


	public void setComm_rate(double comm_rate) {
		Comm_rate = comm_rate;
	}


	public int getSales() {
		return sales;
	}


	public void setSales(int sales) {
		this.sales = sales;
	}


	@Override
	public void acceptData() {
		// TODO Auto-generated method stub
		System.out.println("enter the firstname");
		setFirstname(sc.next());
		System.out.println("enter the lastname");
		setLastname(sc.next());
		System.out.println("enter the SSN");
		setSSN(sc.nextInt());
		System.out.println("enter the Sales");
		sales=sc.nextInt();
		}
	

	@Override
	public String toString() {
		return "Comm_emp [salary=" + salary + ", Comm_rate=" + Comm_rate + ", sales=" + sales + ", getFirstname()="
				+ getFirstname() + ", getLastname()=" + getLastname() + ", getSSN()=" + getSSN() + "]";
	}


	@Override
	public void calSal() {
		// TODO Auto-generated method stub
		salary=sales*Comm_rate;
		System.out.println("your total salary is "+salary);
		
	}

}
