package com.sundeam;

import java.util.Scanner;

public class Sal_emp extends Employee {
	Scanner sc=new Scanner(System.in);
	double weekly_sal;

	public double getWeekly_sal() {
		return weekly_sal;
	}

	public void setWeekly_sal(double weekly_sal) {
		this.weekly_sal = weekly_sal;
	}

	

	

	@Override
	public String toString() {
		return "Sal_emp [weekly_sal=" + weekly_sal + ", First name=" + getFirstname() + ", Last name="
				+ getLastname() + ", SSN=" + getSSN() + "]";
	}

	@Override
	public void acceptData() {
		// TODO Auto-generated method stub
		System.out.println("enter the firstname");
		setFirstname(sc.next());
		System.out.println("enter the lastname");
		setLastname(sc.next());
		System.out.println("enter the SSN");
		setSSN(sc.nextInt());
	}

	@Override
	public void calSal() {
		System.out.println(10000);
		// TODO Auto-generated method stub
	}
	

}
